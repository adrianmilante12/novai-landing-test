export default function Demo() {
  return (
 <section id="demo" className="demo container">
    <h2>Live Preview</h2>
    <div className="demo-frame">
      Demo preview iframe goes here
    </div>
  </section>
  );
}
