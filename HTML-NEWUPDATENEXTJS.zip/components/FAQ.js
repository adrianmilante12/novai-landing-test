export default function Loader() {
  return (
     <div className="faq-item">
      <button className="faq-question">Do I need coding experience?</button>
      <div className="faq-answer">Basic HTML knowledge helps, but documentation is included.</div>
    </div>
    
  );
  
}