

document.addEventListener("DOMContentLoaded", function() {
      const hamburger = document.getElementById("hamburger");
      const bottomSheet = document.getElementById("bottomSheet");
      const grabBtn = document.getElementById("grabBtn");
      
      let startY = 0;
      let sheetStart = 0;
      let isDragging = false;
      let isClosing = false;
      
      function openSheet() {
        if (bottomSheet.classList.contains("active") || isClosing) return;
        isClosing = false;
        
        bottomSheet.style.transition = "none";
        bottomSheet.style.transform = "translateY(100%)";
        
        requestAnimationFrame(() => {
          bottomSheet.style.transition = "transform 0.4s cubic-bezier(0.25,1,0.5,1)";
          bottomSheet.classList.add("active");
          bottomSheet.style.transform = "translateY(0)";
        });
      }
      
      function closeSheet() {
        if (!bottomSheet.classList.contains("active") || isClosing) return;
        isClosing = true;
        
        bottomSheet.style.transition = "transform 0.4s cubic-bezier(0.25,1,0.5,1)";
        bottomSheet.style.transform = "translateY(100%)";
        
        bottomSheet.addEventListener("transitionend", function handler() {
          bottomSheet.classList.remove("active");
          bottomSheet.style.transform = "";
          isClosing = false;
          bottomSheet.removeEventListener("transitionend", handler);
        });
      }
      
      // Hamburger toggle
      hamburger.addEventListener("click", () => {
        if (bottomSheet.classList.contains("active")) {
          closeSheet();
        } else {
          openSheet();
        }
      });
      
      // Drag start
      function dragStart(e) {
        if (isClosing) return;
        isDragging = true;
        bottomSheet.style.transition = "none";
        
        startY = e.type.includes("touch") ? e.touches[0].pageY : e.pageY;
        
        // Read the current transform to get the starting sheet position
        const computedStyle = window.getComputedStyle(bottomSheet);
        const matrix = new WebKitCSSMatrix(computedStyle.transform);
        sheetStart = matrix.m42 || 0; // current offset
        
        document.addEventListener("mousemove", onDrag);
        document.addEventListener("touchmove", onDrag, { passive: false }); // prevent scrolling
        document.addEventListener("mouseup", dragEnd);
        document.addEventListener("touchend", dragEnd);
      }
      
      function onDrag(e) {
        if (!isDragging) return;
        
        const currentY = e.type.includes("touch") ? e.touches[0].pageY : e.pageY;
        let diff = currentY - startY;
        
        if (diff > 0) { // only drag down
          bottomSheet.style.transform = `translateY(${sheetStart + diff}px)`;
        } else {
          bottomSheet.style.transform = `translateY(${sheetStart}px)`;
        }
        
        // Prevent page scrolling during drag
        if (e.type.includes("touch")) e.preventDefault();
      }
      
      function dragEnd() {
        if (!isDragging) return;
        isDragging = false;
        
        document.removeEventListener("mousemove", onDrag);
        document.removeEventListener("touchmove", onDrag);
        document.removeEventListener("mouseup", dragEnd);
        document.removeEventListener("touchend", dragEnd);
        
        // Get final transform
        const computedStyle = window.getComputedStyle(bottomSheet);
        const matrix = new WebKitCSSMatrix(computedStyle.transform);
        const translateY = matrix.m42;
        
        bottomSheet.style.transition = "transform 0.4s cubic-bezier(0.25,1,0.5,1)";
        
        if (translateY > 50) { // hide if dragged far
          closeSheet();
        } else {
          bottomSheet.style.transform = "translateY(0)"; // snap back
        }
      }
      
      grabBtn.addEventListener("mousedown", dragStart);
      grabBtn.addEventListener("touchstart", dragStart);
      
      // Close by clicking grab button
      grabBtn.addEventListener("click", closeSheet);
    });

// Floating sidebar toggle
const floatingBtn = document.querySelector('.floating-cat-btn');
const sidebar = document.querySelector('.categories-sidebar');
floatingBtn.addEventListener('click', () => {
  sidebar.style.display = sidebar.style.display === 'flex' ? 'none' : 'flex';
});

// Category filter
const catButtons = document.querySelectorAll('.cat-item');
const allSections = document.querySelectorAll('.category-section');
const recommendedSection = document.getElementById('recommended-section');

catButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    catButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const category = btn.dataset.category;
    if(category === 'all') {
      allSections.forEach(sec => sec.style.display = 'block');
      recommendedSection.style.display = 'block';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      allSections.forEach(sec => sec.style.display = sec.dataset.category === category ? 'block' : 'none');
      recommendedSection.style.display = 'none';
      const section = document.querySelector(`.category-section[data-category="${category}"]`);
      if(section) section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    sidebar.style.display = 'none';
  });
});

    // Draggable/Swipe carousels
function makeCarouselInteractive(carousels) {
  carousels.forEach(carousel => {
    let isDown = false, startX, scrollLeft;
    carousel.addEventListener('mousedown', e => { isDown=true; startX=e.pageX-carousel.offsetLeft; scrollLeft=carousel.scrollLeft; });
    carousel.addEventListener('mouseleave',()=>isDown=false);
    carousel.addEventListener('mouseup',()=>isDown=false);
    carousel.addEventListener('mousemove',e=>{ if(!isDown) return; e.preventDefault(); carousel.scrollLeft = scrollLeft - (e.pageX-startX)*2; });
    carousel.addEventListener('touchstart', e=> startX = e.touches[0].pageX - carousel.offsetLeft);
    carousel.addEventListener('touchmove', e=> { carousel.scrollLeft -= (e.touches[0].pageX - startX)*2; startX = e.touches[0].pageX - carousel.offsetLeft; });
  });
}
makeCarouselInteractive(document.querySelectorAll('.carousel'));
makeCarouselInteractive(document.querySelectorAll('.recommended-carousel'));

// Infinite smooth scroll for recommended
window.addEventListener("load", function () {
  const carousel = document.getElementById("recommended-carousel");
  if (!carousel) return;

  const originalCards = Array.from(carousel.children);

  // Duplicate cards for seamless loop
  originalCards.forEach(card => {
    const clone = card.cloneNode(true);
    carousel.appendChild(clone);
  });

  let position = 0;
  const speed = 0.5;

  // IMPORTANT: Get original width only (before transform starts)
  const totalWidth = carousel.scrollWidth / 2;

  function animate() {
    position -= speed;

    // Reset when first set fully scrolled
    if (-position >= totalWidth) {
      position = 0;
    }

    carousel.style.transform = `translateX(${position}px)`;
    requestAnimationFrame(animate);
  }

  animate();
});



// Modal popup
const modal = document.getElementById('modal');
const modalImg = document.getElementById('modal-img');
const modalTitle = document.getElementById('modal-title');
const modalDesc = document.getElementById('modal-desc');
const modalDemo = document.getElementById('modal-demo');
const closeBtn = document.querySelector('.close-btn');

function openModal(title, desc, demo, img) {
  modalTitle.textContent = title;
  modalDesc.textContent = desc;
  modalDemo.href = demo;
  modalImg.src = img;
  modal.style.display = 'flex';
}
closeBtn.onclick = () => modal.style.display = 'none';
window.onclick = e => { if(e.target == modal) modal.style.display = 'none'; }

document.querySelectorAll('.recommended-card, .template-card').forEach(card => {
  card.addEventListener('click', () => {
    const title = card.dataset.title;
    const desc = card.dataset.desc;
    const demo = card.dataset.demo;
    const img = card.querySelector('img').src;
    openModal(title, desc, demo, img);
  });
});

// Live Search functionality with dropdown
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.getElementById('search-input');
  const searchResults = document.getElementById('search-results');
  const allCards = Array.from(document.querySelectorAll('.template-card, .recommended-card'));

  // Open modal function (already in your code)
  const modal = document.getElementById('modal');
  const modalImg = document.getElementById('modal-img');
  const modalTitle = document.getElementById('modal-title');
  const modalDesc = document.getElementById('modal-desc');
  const modalDemo = document.getElementById('modal-demo');

  function openModal(title, desc, demo, img) {
    modalTitle.textContent = title;
    modalDesc.textContent = desc;
    modalDemo.href = demo;
    modalImg.src = img;
    modal.style.display = 'flex';
  }

  searchInput.addEventListener('input', () => {
    const query = searchInput.value.toLowerCase();
    searchResults.innerHTML = '';

    if(query.trim() === '') {
      searchResults.style.display = 'none';
      return;
    }

    const matches = allCards.filter(card => card.dataset.title.toLowerCase().includes(query));

    if(matches.length === 0) {
      searchResults.style.display = 'none';
      return;
    }

    matches.forEach(card => {
      const div = document.createElement('div');
      div.textContent = card.dataset.title;
      div.style.padding = '10px';
      div.style.cursor = 'pointer';
      div.style.borderBottom = '1px solid #374151';
      div.style.color = '#fff';
      div.addEventListener('mouseenter', () => div.style.backgroundColor = '#2563eb');
      div.addEventListener('mouseleave', () => div.style.backgroundColor = '#1f2937');
      div.addEventListener('click', () => {
        const title = card.dataset.title;
        const desc = card.dataset.desc;
        const demo = card.dataset.demo;
        const img = card.querySelector('img').src;
        openModal(title, desc, demo, img);
        searchResults.style.display = 'none';
        searchInput.value = '';
      });
      searchResults.appendChild(div);
    });

    searchResults.style.display = 'block';
  });

  // Close dropdown if click outside
  document.addEventListener('click', e => {
    if(!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
      searchResults.style.display = 'none';
    }
  });
});